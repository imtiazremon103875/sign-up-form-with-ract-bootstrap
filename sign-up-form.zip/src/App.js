
import './App.css';
import SignUpform from './component/SignUpform';
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <div className="App">
   
<SignUpform/>
    </div>
  );
}

export default App;
